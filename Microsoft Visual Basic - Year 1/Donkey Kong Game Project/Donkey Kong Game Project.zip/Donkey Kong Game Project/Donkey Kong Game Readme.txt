Controls are:
Left and right arrow keys to move correspondingly
Up and down arros to climb ladders

Space bar to jump

There are many glitches as this was the first game I created using visual basic

Use the EXE in the main folder to run the game

It does not have close button so either lose the game or force close it with the task manager