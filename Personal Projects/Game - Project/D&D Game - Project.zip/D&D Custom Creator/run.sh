#!/bin/sh
java -jar Jonny_game.jar
